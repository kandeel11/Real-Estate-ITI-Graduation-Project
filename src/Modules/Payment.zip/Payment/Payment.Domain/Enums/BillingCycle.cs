namespace Payment.Domain.Enums;

/// <summary>
/// دورة الفوترة — شهري أو سنوي
/// </summary>
public enum BillingCycle
{
    Monthly = 0,
    Yearly = 1
}
