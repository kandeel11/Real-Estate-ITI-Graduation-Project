namespace Payment.Domain.Enums;

/// <summary>
/// نوع الدفعة — بيحدد هل دي إيجار ولا اشتراك
/// </summary>
public enum PaymentType
{
    Rent = 0,
    Subscription = 1
}
