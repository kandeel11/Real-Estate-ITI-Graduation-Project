using Payment.Domain.Enums;

namespace Payment.Domain.Entities;

/// <summary>
/// تفاصيل دفعة الاشتراك — relation 1:1 مع RentPayment
/// بدون أي FK لجداول Subscription module (modular boundary)
/// </summary>
public class SubscriptionPaymentDetails
{
    public Guid Id { get; private set; }
    public Guid PaymentId { get; private set; }

    /// <summary>معرف الاشتراك في Subscription module — بدون FK</summary>
    public Guid SubscriptionId { get; private set; }

    /// <summary>معرف الخطة المطلوبة — بدون FK</summary>
    public Guid PlanId { get; private set; }

    /// <summary>الخطة السابقة — مستخدم بس في Upgrade</summary>
    public Guid? PreviousPlanId { get; private set; }

    public BillingCycle BillingCycle { get; private set; }
    public SubscriptionPaymentPurpose Purpose { get; private set; }

    public DateTime CreatedAt { get; private set; }
    public DateTime UpdatedAt { get; private set; }

    private SubscriptionPaymentDetails() { }

    public static SubscriptionPaymentDetails Create(
        Guid paymentId,
        Guid subscriptionId,
        Guid planId,
        BillingCycle billingCycle,
        SubscriptionPaymentPurpose purpose,
        Guid? previousPlanId = null)
    {
        return new SubscriptionPaymentDetails
        {
            Id = Guid.NewGuid(),
            PaymentId = paymentId,
            SubscriptionId = subscriptionId,
            PlanId = planId,
            PreviousPlanId = previousPlanId,
            BillingCycle = billingCycle,
            Purpose = purpose,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };
    }
}
