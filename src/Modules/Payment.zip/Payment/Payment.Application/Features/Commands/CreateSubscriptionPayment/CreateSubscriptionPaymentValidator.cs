using FluentValidation;
using Payment.Domain.Enums;

namespace Payment.Application.Features.Commands.CreateSubscriptionPayment;

/// <summary>
/// Validator بتاع CreateSubscriptionPaymentCommand
///
/// قواعد:
/// - UserId و PlanId مطلوبين دايماً
/// - SubscriptionId مطلوب لو Purpose=Renewal أو Upgrade
/// - PreviousPlanId مطلوب لو Purpose=Upgrade
/// </summary>
public sealed class CreateSubscriptionPaymentValidator
    : AbstractValidator<CreateSubscriptionPaymentCommand>
{
    public CreateSubscriptionPaymentValidator()
    {
        RuleFor(x => x.UserId)
            .NotEmpty()
            .WithMessage("UserId مطلوب.");

        RuleFor(x => x.PlanId)
            .NotEmpty()
            .WithMessage("PlanId مطلوب.");

        RuleFor(x => x.BillingCycle)
            .IsInEnum()
            .WithMessage("BillingCycle لازم يكون Monthly أو Yearly.");

        RuleFor(x => x.Purpose)
            .IsInEnum()
            .WithMessage("Purpose لازم يكون NewSubscription, Renewal أو Upgrade.");

        When(x => x.Purpose is SubscriptionPaymentPurpose.Renewal
                              or SubscriptionPaymentPurpose.Upgrade, () =>
        {
            RuleFor(x => x.SubscriptionId)
                .NotNull()
                .WithMessage("SubscriptionId مطلوب لعمليات التجديد أو الترقية.");
        });

        When(x => x.Purpose == SubscriptionPaymentPurpose.Upgrade, () =>
        {
            RuleFor(x => x.PreviousPlanId)
                .NotNull()
                .WithMessage("PreviousPlanId مطلوب لعمليات الترقية.");
        });
    }
}
