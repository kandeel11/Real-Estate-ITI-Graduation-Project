using MediatR;
using Microsoft.Extensions.Logging;
using Payment.Application.Exceptions;
using Payment.Application.Interfaces;
using Payment.Domain.Entities;
using Payment.Domain.Enums;

namespace Payment.Application.Features.Commands.CreateSubscriptionPayment;

/// <summary>
/// Handler بتاع CreateSubscriptionPaymentCommand
///
/// الخطوات:
/// 1. يجيب تفاصيل الخطة من Subscription module (عبر ISubscriptionPlanService)
/// 2. يحدد المبلغ بناءً على BillingCycle (شهري/سنوي)
/// 3. ينشئ RentPayment بـ PaymentType=Subscription
/// 4. يربط SubscriptionPaymentDetails (SubscriptionId, PlanId, Purpose...)
/// 5. ينشئ Stripe Checkout Session
/// 6. يحفظ CheckoutSessionId + CheckoutUrl على الـ Payment
/// 7. يحفظ كل ده في معاملة واحدة (Unit of Work)
/// </summary>
public sealed class CreateSubscriptionPaymentHandler
    : IRequestHandler<CreateSubscriptionPaymentCommand, CreateSubscriptionPaymentResult>
{
    private readonly IRentPaymentRepository _paymentRepository;
    private readonly ISubscriptionPlanService _subscriptionPlanService;
    private readonly IStripeCheckoutService _stripeCheckoutService;
    private readonly IUnitOfWork _unitOfWork;
    private readonly ILogger<CreateSubscriptionPaymentHandler> _logger;

    public CreateSubscriptionPaymentHandler(
        IRentPaymentRepository paymentRepository,
        ISubscriptionPlanService subscriptionPlanService,
        IStripeCheckoutService stripeCheckoutService,
        IUnitOfWork unitOfWork,
        ILogger<CreateSubscriptionPaymentHandler> logger)
    {
        _paymentRepository = paymentRepository;
        _subscriptionPlanService = subscriptionPlanService;
        _stripeCheckoutService = stripeCheckoutService;
        _unitOfWork = unitOfWork;
        _logger = logger;
    }

    public async Task<CreateSubscriptionPaymentResult> Handle(
        CreateSubscriptionPaymentCommand request,
        CancellationToken cancellationToken)
    {
        // 1. جيب تفاصيل الخطة من Subscription module
        var plan = await _subscriptionPlanService.GetPlanByIdAsync(request.PlanId, cancellationToken)
            ?? throw new PlanNotFoundException(request.PlanId);

        if (!plan.IsActive)
            throw new InvalidOperationException($"Plan '{plan.Name}' is not currently active.");

        // 2. حدد المبلغ بناءً على Billing Cycle
        var amount = request.BillingCycle == BillingCycle.Yearly
            ? plan.YearlyPrice
            : plan.MonthlyPrice;

        // 3. أنشئ سجل الدفع (Pending)
        var payment = RentPayment.CreateSubscriptionPayment(
            amount: amount,
            notes: $"{request.Purpose} - Plan: {plan.Name} ({request.BillingCycle})");

        // 4. أنشئ تفاصيل الاشتراك المرتبطة
        var subscriptionDetails = SubscriptionPaymentDetails.Create(
            paymentId: payment.Id,
            subscriptionId: request.SubscriptionId ?? Guid.NewGuid(), // مؤقت لو NewSubscription
            planId: request.PlanId,
            billingCycle: request.BillingCycle,
            purpose: request.Purpose,
            previousPlanId: request.PreviousPlanId);

        payment.AttachSubscriptionDetails(subscriptionDetails);

        // 5. أنشئ Stripe Checkout Session
        var checkoutSession = await _stripeCheckoutService.CreateCheckoutSessionAsync(
            new CreateCheckoutSessionRequest(
                PaymentId: payment.Id,
                Amount: amount,
                ProductName: $"{plan.Name} Subscription ({request.BillingCycle})",
                SuccessUrl: request.SuccessRedirectUrl ?? "https://app.example.com/subscription/success",
                CancelUrl: request.CancelRedirectUrl ?? "https://app.example.com/subscription/cancel",
                Metadata: new Dictionary<string, string>
                {
                    ["payment_id"] = payment.Id.ToString(),
                    ["payment_type"] = "Subscription",
                    ["user_id"] = request.UserId.ToString(),
                    ["plan_id"] = request.PlanId.ToString(),
                    ["purpose"] = request.Purpose.ToString()
                }),
            cancellationToken);

        // 6. خزّن بيانات الـ Checkout على الـ Payment
        payment.SetCheckoutSession(checkoutSession.SessionId, checkoutSession.Url);

        // 7. حفظ كل ده في معاملة واحدة
        await _paymentRepository.AddAsync(payment, cancellationToken);
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        _logger.LogInformation(
            "Subscription payment {PaymentId} created for User={UserId}, Plan={PlanId}, Purpose={Purpose}. CheckoutSession={SessionId}",
            payment.Id, request.UserId, request.PlanId, request.Purpose, checkoutSession.SessionId);

        return new CreateSubscriptionPaymentResult(
            PaymentId: payment.Id,
            CheckoutUrl: checkoutSession.Url,
            CheckoutSessionId: checkoutSession.SessionId);
    }
}
