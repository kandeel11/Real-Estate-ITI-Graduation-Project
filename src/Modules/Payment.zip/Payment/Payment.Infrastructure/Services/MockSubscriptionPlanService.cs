using Payment.Application.Interfaces;

namespace Payment.Infrastructure.Services;

/// <summary>
/// Mock implementation للـ ISubscriptionPlanService
/// يُستخدم للتطوير والاختبار — في الـ production يُستبدل بـ real implementation
/// من Subscription.Infrastructure (Adapter Pattern — يطبق ISubscriptionPlanService
/// المُعرّف في Payment.Application)
///
/// لتفعيل الـ real implementation:
/// في Subscription module's DI extension سجّل:
///     services.AddScoped&lt;Payment.Application.Interfaces.ISubscriptionPlanService,
///                          Subscription.Infrastructure.Adapters.SubscriptionPlanServiceImpl&gt;();
/// وده هيغلب على الـ TryAddScoped بتاع الـ Mock هنا
/// (بشرط أن AddSubscriptionModule يُستدعى بعد AddPaymentModule في Program.cs)
/// </summary>
public sealed class MockSubscriptionPlanService : ISubscriptionPlanService
{
    private static readonly Dictionary<Guid, SubscriptionPlanDto> Plans = new()
    {
        [Guid.Parse("aaaaaaaa-0000-0000-0000-000000000001")] = new(
            PlanId: Guid.Parse("aaaaaaaa-0000-0000-0000-000000000001"),
            Name: "Basic",
            MonthlyPrice: 99m,
            YearlyPrice: 999m,
            IsActive: true),

        [Guid.Parse("aaaaaaaa-0000-0000-0000-000000000002")] = new(
            PlanId: Guid.Parse("aaaaaaaa-0000-0000-0000-000000000002"),
            Name: "Pro",
            MonthlyPrice: 249m,
            YearlyPrice: 2499m,
            IsActive: true),

        [Guid.Parse("aaaaaaaa-0000-0000-0000-000000000003")] = new(
            PlanId: Guid.Parse("aaaaaaaa-0000-0000-0000-000000000003"),
            Name: "Enterprise",
            MonthlyPrice: 599m,
            YearlyPrice: 5999m,
            IsActive: true)
    };

    public Task<SubscriptionPlanDto?> GetPlanByIdAsync(Guid planId, CancellationToken cancellationToken = default)
    {
        Plans.TryGetValue(planId, out var plan);
        return Task.FromResult(plan);
    }

    public Task<SubscriptionDto?> GetSubscriptionByIdAsync(Guid subscriptionId, CancellationToken cancellationToken = default)
    {
        // في الـ Mock: نرجع subscription وهمي بحالة PendingPayment
        var dto = new SubscriptionDto(
            SubscriptionId: subscriptionId,
            UserId: Guid.NewGuid(),
            PlanId: Plans.Keys.First(),
            Status: "PendingPayment",
            CurrentPeriodEnd: null);

        return Task.FromResult<SubscriptionDto?>(dto);
    }

    public Task<SubscriptionDto?> GetActiveSubscriptionForUserAsync(Guid userId, CancellationToken cancellationToken = default)
    {
        // في الـ Mock: نفترض إن المستخدم مالوش اشتراك فعال
        return Task.FromResult<SubscriptionDto?>(null);
    }
}
