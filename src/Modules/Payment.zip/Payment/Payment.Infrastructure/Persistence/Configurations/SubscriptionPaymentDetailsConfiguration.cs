using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Payment.Domain.Entities;

namespace Payment.Infrastructure.Persistence.Configurations;

/// <summary>
/// Configuration بتاع جدول subscription_payments
/// Relation 1:1 مع RentPayment عبر PaymentId
/// </summary>
public sealed class SubscriptionPaymentDetailsConfiguration
    : IEntityTypeConfiguration<SubscriptionPaymentDetails>
{
    public void Configure(EntityTypeBuilder<SubscriptionPaymentDetails> builder)
    {
        builder.ToTable("subscription_payments", "payment");

        builder.HasKey(x => x.Id);
        builder.Property(x => x.Id).ValueGeneratedNever();

        builder.Property(x => x.PaymentId).IsRequired();
        builder.Property(x => x.SubscriptionId).IsRequired();
        builder.Property(x => x.PlanId).IsRequired();
        builder.Property(x => x.PreviousPlanId).IsRequired(false);

        builder.Property(x => x.BillingCycle)
            .HasConversion<string>()
            .HasMaxLength(20)
            .IsRequired();

        builder.Property(x => x.Purpose)
            .HasConversion<string>()
            .HasMaxLength(20)
            .IsRequired();

        builder.Property(x => x.CreatedAt).IsRequired();
        builder.Property(x => x.UpdatedAt).IsRequired();

        builder.HasIndex(x => x.SubscriptionId)
            .HasDatabaseName("IX_subscription_payments_subscription_id");

        builder.HasIndex(x => x.PaymentId)
            .IsUnique()
            .HasDatabaseName("IX_subscription_payments_payment_id");

        // العلاقة 1:1 مع RentPayment عبر shadow FK على PaymentId
        builder.HasOne<RentPayment>()
            .WithOne(p => p.SubscriptionDetails)
            .HasForeignKey<SubscriptionPaymentDetails>(x => x.PaymentId)
            .OnDelete(DeleteBehavior.Cascade);
    }
}
