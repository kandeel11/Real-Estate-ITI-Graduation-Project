using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Payment.Application;
using Payment.Application.Interfaces;
using Payment.Infrastructure.BackgroundJobs;
using Payment.Infrastructure.Outbox;
using Payment.Infrastructure.Persistence;
using Payment.Infrastructure.Persistence.Repositories;
using Payment.Infrastructure.Services;
using Payment.Infrastructure.Services.Stripe;
using Payment.Infrastructure.Settings;

namespace Payment.Infrastructure;

public static class PaymentModuleExtensions
{
    public static IServiceCollection AddPaymentModule(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.AddPaymentApplication();

        services.AddDbContext<PaymentDbContext>(options =>
            options.UseSqlServer(
                configuration.GetConnectionString("DefaultConnection"),
                sql => sql.MigrationsHistoryTable("__EFMigrationsHistory", "payment")));

        services.AddScoped<IPaymentDbContext>(sp =>
            sp.GetRequiredService<PaymentDbContext>());

        services.AddScoped<IRentPaymentRepository, RentPaymentRepository>();
        services.AddScoped<IUnitOfWork, UnitOfWork>();

        services.Configure<StripeSettings>(
            configuration.GetSection(StripeSettings.SectionName));

        services.AddScoped<StripePaymentGatewayService>();
        services.AddScoped<IPaymentGatewayService, StripePaymentGatewayService>();

        services.AddScoped<IStripeCheckoutService, StripeCheckoutService>();

        services.AddScoped<StripeWebhookService>();

        services.AddScoped<IOutboxWriter, OutboxWriter>();
        services.AddHostedService<OutboxPublisherJob>();

        services.Configure<OverdueJobSettings>(
            configuration.GetSection(OverdueJobSettings.SectionName));
        services.AddHostedService<OverduePaymentsJob>();
        services.AddHostedService<MonthlyPaymentGenerationJob>();

        services.TryAddScoped<ILeaseService, MockLeaseService>();
        services.TryAddScoped<INotificationService, MockNotificationService>();

        services.TryAddScoped<ISubscriptionPlanService, MockSubscriptionPlanService>();

        return services;
    }
}
